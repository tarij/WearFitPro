package com.wearfit.pro

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.hardware.*
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

class MainActivity : ComponentActivity(), SensorEventListener {
    private val steps = mutableStateOf(0)
    private lateinit var hr: HeartRateClient

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        hr = HeartRateClient(this)
        val perms = mutableListOf(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 31) perms += listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else perms += Manifest.permission.ACCESS_FINE_LOCATION
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startSteps() }
            .launch(perms.toTypedArray())
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App(steps, hr) } }
    }

    private fun startSteps() {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val total = e.values[0].toInt()
        val p = getSharedPreferences("fit", MODE_PRIVATE)
        val today = LocalDate.now().toString()
        if (p.getString("day", "") != today) p.edit().putString("day", today).putInt("base", total).apply()
        steps.value = total - p.getInt("base", total)
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

@SuppressLint("MissingPermission")
@Composable
fun App(steps: State<Int>, hr: HeartRateClient) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Home" to Icons.Default.Home, "Heart" to Icons.Default.Favorite, "Sleep" to Icons.Default.Bedtime, "Faces" to Icons.Default.Watch, "Debug" to Icons.Default.BugReport)
                .forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l) })
                }
        }
    }) { pad ->
        Box(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            when (tab) {
                0 -> Home(steps.value, hr.bpm.value)
                1 -> Heart(hr)
                2 -> Sleep()
                3 -> Faces(steps.value, hr.bpm.value)
                else -> Debug()
            }
        }
    }
}

@Composable
fun Home(steps: Int, bpm: Int) {
    val goal = 8000
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Today", fontSize = 22.sp)
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val st = Stroke(22f, cap = StrokeCap.Round)
                drawArc(Color.DarkGray, 0f, 360f, false, style = st)
                drawArc(Color(0xFF00E676), -90f, 360f * (steps / goal.toFloat()).coerceAtMost(1f), false, style = st)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$steps", fontSize = 40.sp); Text("/ $goal steps")
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Calories", "${(steps * 0.04).toInt()} kcal")
            Stat("Distance", "%.2f km".format(steps * 0.0008))
            Stat("Heart", if (bpm > 0) "$bpm bpm" else "--")
        }
    }
}

@Composable
fun Stat(label: String, value: String) = Card { Column(Modifier.padding(14.dp)) { Text(label, fontSize = 12.sp); Text(value, fontSize = 16.sp) } }

@SuppressLint("MissingPermission")
@Composable
fun Heart(hr: HeartRateClient) {
    Column {
        Text(if (hr.bpm.value > 0) "${hr.bpm.value} bpm" else "-- bpm", fontSize = 48.sp, color = Color(0xFFFF5252))
        Text(hr.status.value)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { hr.scan() }) { Text("Scan for watch / band") }
        LazyColumn { items(hr.devices) { d ->
            ListItem(headlineContent = { Text(d.name ?: "Unknown") }, supportingContent = { Text(d.address) },
                trailingContent = { TextButton(onClick = { hr.connect(d) }) { Text("Connect") } })
        } }
    }
}

@Composable
fun Sleep() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = remember { ctx.getSharedPreferences("fit", Context.MODE_PRIVATE) }
    var hours by remember { mutableStateOf(p.getFloat("sleep", 7f)) }
    Column {
        Text("Sleep", fontSize = 22.sp)
        Text("%.1f h".format(hours), fontSize = 48.sp)
        Slider(value = hours, onValueChange = { hours = it; p.edit().putFloat("sleep", it).apply() }, valueRange = 0f..12f)
        Text(if (hours >= 7) "Goal reached (7h+)" else "Below 7h goal")
    }
}
