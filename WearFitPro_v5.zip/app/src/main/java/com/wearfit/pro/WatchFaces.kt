package com.wearfit.pro

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

val faceNames = listOf("Classic", "Minimal", "Neon", "Sport", "Sunset", "Mono")

@Composable
fun rememberNow(): State<LocalTime> = produceState(LocalTime.now()) {
    while (true) { value = LocalTime.now(); delay(1000) }
}

@Composable
fun Analog(t: LocalTime, fg: Color, accent: Color, ticks: Boolean) {
    Canvas(Modifier.fillMaxSize().padding(10.dp)) {
        val c = center; val r = size.minDimension / 2
        fun dir(deg: Double) = Offset(cos(Math.toRadians(deg - 90)).toFloat(), sin(Math.toRadians(deg - 90)).toFloat())
        if (ticks) for (i in 0 until 12) drawLine(fg, c + dir(i * 30.0) * (r * 0.86f), c + dir(i * 30.0) * r, 4f, StrokeCap.Round)
        fun hand(deg: Double, len: Float, w: Float, col: Color) = drawLine(col, c, c + dir(deg) * (r * len), w, StrokeCap.Round)
        hand((t.hour % 12 + t.minute / 60.0) * 30, 0.50f, 10f, fg)
        hand((t.minute + t.second / 60.0) * 6, 0.75f, 6f, fg)
        hand(t.second * 6.0, 0.85f, 3f, accent)
    }
}

@Composable
fun Digital(t: LocalTime, color: Color, accent: Color, big: Boolean, steps: Int, bpm: Int, showInfo: Boolean) {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(t.format(DateTimeFormatter.ofPattern("HH:mm")), color = color, fontSize = if (big) 44.sp else 36.sp)
        Text(t.format(DateTimeFormatter.ofPattern(":ss")), color = accent, fontSize = 16.sp)
        Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM")), color = color.copy(alpha = .7f), fontSize = 12.sp)
        if (showInfo) Text("$steps steps  •  ${if (bpm > 0) bpm else "--"} bpm", color = accent, fontSize = 11.sp)
    }
}

@Composable
fun WatchFace(id: Int, size: Dp, steps: Int = 0, bpm: Int = 0) {
    val t by rememberNow()
    val bg = when (id) {
        0 -> Modifier.background(Color(0xFF101418), CircleShape)
        1 -> Modifier.background(Color.White, CircleShape)
        2 -> Modifier.background(Color.Black, CircleShape)
        3 -> Modifier.background(Color(0xFF0B1F33), CircleShape)
        4 -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFFFF7E5F), Color(0xFF6A3093))), CircleShape)
        else -> Modifier.background(Color(0xFF1C1C1E), CircleShape)
    }
    Box(Modifier.size(size).clip(CircleShape).then(bg)) {
        when (id) {
            0 -> Analog(t, Color.White, Color(0xFF00E676), true)
            1 -> Analog(t, Color.Black, Color(0xFFFF5252), false)
            2 -> Digital(t, Color(0xFF00E5FF), Color(0xFFFF4081), true, steps, bpm, false)
            3 -> Digital(t, Color.White, Color(0xFF00E676), false, steps, bpm, true)
            4 -> Analog(t, Color.White, Color(0xFFFFEB3B), true)
            else -> Digital(t, Color.White, Color(0xFF9E9E9E), true, steps, bpm, false)
        }
    }
}

@Composable
fun Faces(steps: Int, bpm: Int) {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("fit", android.content.Context.MODE_PRIVATE) }
    var sel by remember { mutableIntStateOf(p.getInt("face", 0)) }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Watch Faces", fontSize = 22.sp)
        Text("All free", fontSize = 12.sp, color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        WatchFace(sel, 200.dp, steps, bpm)
        Spacer(Modifier.height(4.dp))
        Text("${faceNames[sel]} • Active")
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(faceNames.indices.toList()) { i ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { sel = i; p.edit().putInt("face", i).apply() }) {
                    Box(Modifier.border(BorderStroke(if (i == sel) 3.dp else 0.dp, Color(0xFF00E676)), CircleShape)) { WatchFace(i, 90.dp, steps, bpm) }
                    Text(faceNames[i], fontSize = 12.sp)
                }
            }
        }
    }
}
