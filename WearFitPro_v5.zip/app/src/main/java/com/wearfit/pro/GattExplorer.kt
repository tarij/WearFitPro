package com.wearfit.pro

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Scans all BLE devices, connects, and lists every service/characteristic so the watch protocol can be identified. */
@SuppressLint("MissingPermission")
class GattExplorer(private val ctx: Context) {
    val found = mutableStateListOf<ScanResult>()
    val log = mutableStateListOf<String>()
    private val scanner get() =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.bluetoothLeScanner

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) {
            if (r.device.name != null && found.none { it.device.address == r.device.address }) found.add(r)
        }
    }

    fun scan() { found.clear(); scanner?.startScan(scanCb) ?: log.add("Bluetooth off") }

    fun connect(r: ScanResult) {
        scanner?.stopScan(scanCb); log.clear(); log.add("Connecting ${r.device.name} ${r.device.address}")
        r.device.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }

    private fun props(p: Int) = listOf(2 to "READ", 4 to "WRITE_NR", 8 to "WRITE", 16 to "NOTIFY", 32 to "INDICATE")
        .filter { p and it.first != 0 }.joinToString(",") { it.second }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, s: Int, n: Int) {
            log.add(if (n == BluetoothProfile.STATE_CONNECTED) "Connected" else "Disconnected (status $s)")
            if (n == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, s: Int) {
            g.services.forEach { sv ->
                log.add("SERVICE ${sv.uuid}")
                sv.characteristics.forEach { log.add("  CHAR ${it.uuid} [${props(it.properties)}]") }
            }
            log.add("--- done ---")
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun Debug() {
    val ex = remember { GattExplorer(LocalContext.current) }
    val clip = LocalClipboardManager.current
    Column {
        Text("Watch Debug", fontSize = 22.sp)
        Text("Disconnect watch from WearFit Pro first, then scan.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { ex.scan() }) { Text("Scan") }
            OutlinedButton(onClick = { clip.setText(AnnotatedString(ex.log.joinToString("\n"))) }) { Text("Copy log") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(ex.found.toList()) { r ->
                ListItem(headlineContent = { Text(r.device.name ?: "?") },
                    supportingContent = { Text("${r.device.address}  ${r.rssi} dBm") },
                    modifier = Modifier.clickable { ex.connect(r) })
            }
            items(ex.log.toList()) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}
