package com.wearfit.pro

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Ui {
    val Bg = Color(0xFF060A12)
    val Green = Color(0xFF00E676)
    val Cyan = Color(0xFF22D3EE)
    val Pink = Color(0xFFFF4D8D)
    val Orange = Color(0xFFFFA64D)
    val Purple = Color(0xFF8B7BFF)
    val Muted = Color(0xFF8A94A8)
    val Line = Color(0x1FFFFFFF)
    val CardShape = RoundedCornerShape(24.dp)
}

@Composable
fun WearTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Ui.Green,
            onPrimary = Color.Black,
            secondary = Ui.Cyan,
            background = Ui.Bg,
            surface = Ui.Bg,
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}

/** Dark background with soft colored glows. */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Ui.Bg)
            .drawBehind {
                val r = size.width * 0.9f
                drawRect(
                    brush = Brush.radialGradient(
                        listOf(Color(0x3300E676), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.02f),
                        radius = r
                    )
                )
                drawRect(
                    brush = Brush.radialGradient(
                        listOf(Color(0x2D8B7BFF), Color.Transparent),
                        center = Offset(size.width * 0.0f, size.height * 0.75f),
                        radius = r
                    )
                )
            },
        content = content
    )
}

/** Frosted-glass style card. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .clip(Ui.CardShape)
            .background(Brush.verticalGradient(listOf(Color(0x26FFFFFF), Color(0x0DFFFFFF))))
            .border(1.dp, Ui.Line, Ui.CardShape)
            .then(modifier)
            .padding(16.dp),
        horizontalAlignment = horizontalAlignment,
        content = content
    )
}

@Composable
fun ScreenTitle(title: String, subtitle: String) {
    Column(Modifier.padding(top = 14.dp, bottom = 18.dp)) {
        Text(subtitle, color = Ui.Muted, fontSize = 13.sp)
        Text(title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun IconBadge(icon: ImageVector, tint: Color, size: Dp = 36.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(tint.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(CircleShape).background(color.copy(alpha = 0.15f))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}
