package com.wearfit.pro

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

/** Scans BLE devices, connects, lists services, listens to all notifications and can send raw hex. */
@SuppressLint("MissingPermission")
class GattExplorer(private val ctx: Context) {
    val found = mutableStateListOf<ScanResult>()
    val log = mutableStateListOf<String>()
    private var gatt: BluetoothGatt? = null
    private val queue = ArrayDeque<BluetoothGattCharacteristic>()
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val scanner get() =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.bluetoothLeScanner

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) {
            if (r.device.name != null && found.none { it.device.address == r.device.address }) found.add(r)
        }
    }

    fun scan() { found.clear(); scanner?.startScan(scanCb) ?: log.add("Bluetooth off") }

    fun connect(r: ScanResult) {
        scanner?.stopScan(scanCb); log.clear(); log.add("Connecting ${r.device.name} ${r.device.address}")
        gatt = r.device.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }

    private fun hex(b: ByteArray?) = b?.joinToString(" ") { "%02X".format(it) } ?: ""
    private fun short(c: BluetoothGattCharacteristic) = c.uuid.toString().take(8)

    fun send(uuid: String, hexText: String) {
        val g = gatt ?: run { log.add("Not connected"); return }
        try {
            val c = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == UUID.fromString(uuid.trim()) }
                ?: run { log.add("Characteristic not found"); return }
            val clean = hexText.replace(" ", "")
            c.value = ByteArray(clean.length / 2) { clean.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            c.writeType = if (c.properties and 4 != 0) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            g.writeCharacteristic(c)
            log.add("TX ${short(c)}: ${hex(c.value)}")
        } catch (e: Exception) { log.add("Send error: ${e.message}") }
    }

    private fun next(g: BluetoothGatt) {
        val c = queue.removeFirstOrNull() ?: run { log.add("--- listening for notifications ---"); return }
        g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(cccd) ?: return next(g)
        d.value = if (c.properties and 16 != 0) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        g.writeDescriptor(d)
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, s: Int, n: Int) {
            log.add(if (n == BluetoothProfile.STATE_CONNECTED) "Connected" else "Disconnected (status $s)")
            if (n == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, s: Int) {
            g.services.forEach { sv ->
                log.add("SERVICE ${sv.uuid}")
                sv.characteristics.forEach {
                    log.add("  CHAR ${it.uuid}")
                    if (it.properties and 0x30 != 0 && !it.uuid.toString().startsWith("00002a05")) queue.add(it)
                }
            }
            next(g)
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, s: Int) {
            log.add("sub ${short(d.characteristic)} status $s"); next(g)
        }
        @Deprecated("API<33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            log.add("RX ${short(c)}: ${hex(c.value)}")
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, s: Int) {
            log.add("write ${short(c)} status $s")
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun Debug() {
    val ctx = LocalContext.current
    val ex = remember { GattExplorer(ctx) }
    val clip = LocalClipboardManager.current
    var uuid by remember { mutableStateOf("6e400002-b5a3-f393-e0a9-e50e24dcca9e") }
    var hexText by remember { mutableStateOf("") }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Ui.Cyan,
        unfocusedBorderColor = Color(0x33FFFFFF),
        focusedLabelColor = Ui.Cyan,
        unfocusedLabelColor = Ui.Muted,
        cursorColor = Ui.Cyan
    )
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Watch Debug", "Developer tools")
        Text("Disconnect your watch from WearFit Pro first, then scan.", color = Ui.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { ex.scan() },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ui.Green, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.Search, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Scan", fontWeight = FontWeight.SemiBold)
            }
            OutlinedButton(
                onClick = { clip.setText(AnnotatedString(ex.log.joinToString("\n"))) },
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Copy log")
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = uuid, onValueChange = { uuid = it },
            label = { Text("Characteristic UUID") },
            singleLine = true, shape = RoundedCornerShape(14.dp), colors = fieldColors,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = hexText, onValueChange = { hexText = it },
                label = { Text("Hex bytes e.g. 01 02 FF") },
                singleLine = true, shape = RoundedCornerShape(14.dp), colors = fieldColors,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { ex.send(uuid, hexText) },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ui.Cyan, contentColor = Color.Black)
            ) { Text("Send", fontWeight = FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(ex.found.toList()) { r ->
                GlassCard(Modifier.fillMaxWidth().clickable { ex.connect(r) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Default.Bluetooth, Ui.Cyan, 40.dp)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(r.device.name ?: "?", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${r.device.address}  ${r.rssi} dBm", color = Ui.Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
            items(ex.log.toList()) { line ->
                val col = when {
                    line.startsWith("RX") -> Ui.Cyan
                    line.startsWith("TX") -> Ui.Green
                    line.startsWith("SERVICE") -> Ui.Purple
                    line.startsWith("Send error") || line.contains("Disconnected") -> Ui.Pink
                    else -> Ui.Muted
                }
                Text(
                    line, color = col, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                        .background(Color(0x0DFFFFFF)).padding(8.dp)
                )
            }
        }
    }
}
