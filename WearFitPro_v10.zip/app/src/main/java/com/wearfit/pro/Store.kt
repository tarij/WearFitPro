package com.wearfit.pro

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate

data class Workout(val day: LocalDate, val type: String, val minutes: Int, val kcal: Int)

/** Name to MET value. */
val workoutTypes = listOf("Walk" to 3.5f, "Run" to 9.8f, "Cycle" to 7.5f, "Gym" to 5f, "Yoga" to 3f)

object Store {
    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("fit", Context.MODE_PRIVATE)
    fun stepGoal(p: SharedPreferences) = p.getInt("goal_steps", 8000)
    fun sleepGoal(p: SharedPreferences) = p.getFloat("goal_sleep", 7f)
    fun weight(p: SharedPreferences) = p.getFloat("weight", 70f)
    fun height(p: SharedPreferences) = p.getFloat("height", 170f)
    fun kcalPerStep(p: SharedPreferences) = 0.04f * weight(p) / 70f
    fun km(p: SharedPreferences, steps: Int) = steps * (height(p) * 0.415f) / 100000f

    fun loadWorkouts(p: SharedPreferences): List<Workout> =
        (p.getString("workouts", "") ?: "").lines().mapNotNull { l ->
            val f = l.split("|")
            if (f.size < 4) null
            else try { Workout(LocalDate.parse(f[0]), f[1], f[2].toInt(), f[3].toInt()) } catch (e: Exception) { null }
        }

    fun saveWorkouts(p: SharedPreferences, list: List<Workout>) {
        p.edit().putString("workouts", list.joinToString("\n") { "${it.day}|${it.type}|${it.minutes}|${it.kcal}" }).apply()
    }
}
