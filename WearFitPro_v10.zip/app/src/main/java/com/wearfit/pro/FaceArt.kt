package com.wearfit.pro

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Build
import android.provider.MediaStore
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

const val FACE_W = 485
const val FACE_H = 520
const val FACE_COUNT = 50

val layoutNames = listOf("Classic", "Dots", "Big", "Info", "Date", "Numerals", "Stack", "Rings", "Sweep", "Sport")
val paletteNames = listOf("Midnight", "Emerald", "Sunset", "Mono", "Light")
val faceNames = List(FACE_COUNT) { "${layoutNames[it % 10]} ${paletteNames[it / 10]}" }

private fun argb(v: Long) = v.toInt()

// bg1, bg2, foreground, accent
private val pal = listOf(
    intArrayOf(argb(0xFF0B1020), argb(0xFF1B2A4A), argb(0xFFFFFFFF), argb(0xFF22D3EE)),
    intArrayOf(argb(0xFF04140D), argb(0xFF0B3D2A), argb(0xFFFFFFFF), argb(0xFF00E676)),
    intArrayOf(argb(0xFF2B0B3A), argb(0xFFFF7E5F), argb(0xFFFFFFFF), argb(0xFFFFEB3B)),
    intArrayOf(argb(0xFF000000), argb(0xFF2A2A2E), argb(0xFFFFFFFF), argb(0xFFFF5252)),
    intArrayOf(argb(0xFFF5F5F7), argb(0xFFD8DCE6), argb(0xFF111111), argb(0xFF2979FF))
)

/** Draws face [idx] on a canvas of size w x h. With clock=false only the dial art is drawn (no hands/time). */
fun drawFace(c: Canvas, w: Float, h: Float, idx: Int, t: LocalTime, clock: Boolean, steps: Int = 0, bpm: Int = 0) {
    val lay = idx % 10
    val p = pal[(idx / 10) % pal.size]
    val fg = p[2]
    val ac = p[3]
    val s = w / FACE_W
    val cx = w / 2
    val cy = h / 2
    val r = minOf(w, h) / 2 * 0.9f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.shader = LinearGradient(0f, 0f, w, h, p[0], p[1], Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w, h, paint)
    paint.shader = null

    fun fill(col: Int, a: Int = 255) { paint.style = Paint.Style.FILL; paint.color = col; paint.alpha = a }
    fun stroke(col: Int, wd: Float, a: Int = 255) {
        paint.style = Paint.Style.STROKE; paint.color = col; paint.alpha = a
        paint.strokeWidth = wd * s; paint.strokeCap = Paint.Cap.ROUND
    }
    fun px(deg: Double, rad: Float) = cx + rad * cos(Math.toRadians(deg - 90)).toFloat()
    fun py(deg: Double, rad: Float) = cy + rad * sin(Math.toRadians(deg - 90)).toFloat()
    fun text(str: String, x: Float, y: Float, size: Float, col: Int, a: Int = 255) {
        fill(col, a); paint.textSize = size * s; paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.DEFAULT_BOLD
        c.drawText(str, x, y - (paint.ascent() + paint.descent()) / 2, paint)
    }
    fun ticks(n: Int, inner: Float, wd: Float, col: Int, a: Int = 255) {
        stroke(col, wd, a)
        for (i in 0 until n) {
            val d = i * 360.0 / n
            c.drawLine(px(d, r * inner), py(d, r * inner), px(d, r), py(d, r), paint)
        }
    }
    fun hands(wh: Float, wm: Float, sec: Boolean) {
        if (!clock) return
        val hd = (t.hour % 12 + t.minute / 60.0) * 30
        val md = (t.minute + t.second / 60.0) * 6
        stroke(fg, wh); c.drawLine(cx, cy, px(hd, r * 0.5f), py(hd, r * 0.5f), paint)
        stroke(fg, wm); c.drawLine(cx, cy, px(md, r * 0.78f), py(md, r * 0.78f), paint)
        if (sec) {
            val sd = t.second * 6.0
            stroke(ac, 4f); c.drawLine(cx, cy, px(sd, r * 0.88f), py(sd, r * 0.88f), paint)
        }
        fill(ac); c.drawCircle(cx, cy, 9 * s, paint)
    }

    val hm = "%02d:%02d".format(t.hour, t.minute)
    when (lay) {
        0 -> {
            stroke(ac, 3f, 50); c.drawCircle(cx, cy, r, paint)
            ticks(60, 0.95f, 2f, fg, 110); ticks(12, 0.86f, 7f, fg)
            hands(12f, 8f, true)
        }
        1 -> {
            for (i in 0 until 12) {
                val big = i % 3 == 0
                fill(if (big) ac else fg, if (big) 255 else 160)
                c.drawCircle(px(i * 30.0, r * 0.88f), py(i * 30.0, r * 0.88f), (if (big) 11f else 6f) * s, paint)
            }
            hands(10f, 6f, false)
        }
        2 -> {
            stroke(ac, 6f); c.drawLine(cx - 90 * s, cy + 100 * s, cx + 90 * s, cy + 100 * s, paint)
            if (clock) text(hm, cx, cy - 10 * s, 140f, fg)
        }
        3 -> {
            fill(fg, 28); c.drawRoundRect(RectF(cx - 195 * s, cy + 70 * s, cx + 195 * s, cy + 150 * s), 30 * s, 30 * s, paint)
            if (clock) {
                text(hm, cx, cy - 70 * s, 120f, fg)
                text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM")), cx, cy + 5 * s, 34f, ac)
                text("$steps steps   ${if (bpm > 0) bpm else "--"} bpm", cx, cy + 110 * s, 30f, fg)
            }
        }
        4 -> {
            ticks(60, 0.95f, 2f, fg, 90); ticks(12, 0.86f, 7f, fg)
            stroke(ac, 4f)
            c.drawRoundRect(RectF(cx + r * 0.3f, cy - 26 * s, cx + r * 0.72f, cy + 26 * s), 12 * s, 12 * s, paint)
            if (clock) text(LocalDate.now().dayOfMonth.toString(), cx + r * 0.51f, cy, 36f, fg)
            hands(12f, 8f, true)
        }
        5 -> {
            for (i in 0 until 12) {
                val d = i * 30.0
                if (i % 3 == 0) {
                    val label = when (i) { 0 -> "12"; 3 -> "3"; 6 -> "6"; else -> "9" }
                    text(label, px(d, r * 0.78f), py(d, r * 0.78f), 66f, if (i == 0) ac else fg)
                } else {
                    fill(fg, 150); c.drawCircle(px(d, r * 0.88f), py(d, r * 0.88f), 6 * s, paint)
                }
            }
            hands(12f, 7f, true)
        }
        6 -> {
            stroke(ac, 5f, 160); c.drawLine(cx - 120 * s, cy, cx + 120 * s, cy, paint)
            if (clock) {
                text("%02d".format(t.hour), cx, cy - 100 * s, 190f, fg)
                text("%02d".format(t.minute), cx, cy + 105 * s, 190f, ac)
            }
        }
        7 -> {
            stroke(ac, 14f, 70); c.drawCircle(cx, cy, r * 0.95f, paint)
            stroke(fg, 6f, 60); c.drawCircle(cx, cy, r * 0.78f, paint)
            stroke(fg, 3f, 40); c.drawCircle(cx, cy, r * 0.62f, paint)
            if (clock) {
                stroke(ac, 14f)
                c.drawArc(RectF(cx - r * 0.95f, cy - r * 0.95f, cx + r * 0.95f, cy + r * 0.95f), -90f, t.second * 6f, false, paint)
                text(hm, cx, cy, 96f, fg)
            }
        }
        8 -> {
            val sc = ac and 0x00FFFFFF
            val sh = SweepGradient(cx, cy, intArrayOf(sc, (0xAA shl 24) or sc), null)
            val m = Matrix()
            m.setRotate((if (clock) t.second * 6f else 0f) - 90f, cx, cy)
            sh.setLocalMatrix(m)
            paint.style = Paint.Style.FILL; paint.shader = sh; paint.alpha = 255
            c.drawCircle(cx, cy, r * 0.92f, paint)
            paint.shader = null
            ticks(12, 0.88f, 6f, fg)
            hands(12f, 8f, false)
        }
        else -> {
            val radii = listOf(0.9f, 0.72f, 0.54f)
            val fr = if (clock) listOf((steps / 8000f).coerceIn(0f, 1f), (bpm / 200f).coerceIn(0f, 1f), t.second / 60f)
            else listOf(0.7f, 0.5f, 0.85f)
            val cols = listOf(ac, argb(0xFFFF4D8D), fg)
            radii.forEachIndexed { i, k ->
                val rr = r * k
                stroke(fg, 18f, 40); c.drawCircle(cx, cy, rr, paint)
                stroke(cols[i], 18f)
                c.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), -90f, 360f * fr[i], false, paint)
            }
            if (clock) text(hm, cx, cy, 70f, fg)
        }
    }
}

fun renderFace(idx: Int, clock: Boolean): Bitmap {
    val bmp = Bitmap.createBitmap(FACE_W, FACE_H, Bitmap.Config.ARGB_8888)
    drawFace(Canvas(bmp), FACE_W.toFloat(), FACE_H.toFloat(), idx, LocalTime.of(10, 10, 30), clock, 6240, 72)
    return bmp
}

/** Saves face as a 485x520 PNG into Pictures/WearFitFaces (Android 10+). */
fun saveFace(ctx: Context, idx: Int, clock: Boolean): Boolean = try {
    val bmp = renderFace(idx, clock)
    val name = "WearFit_%02d_%s.png".format(idx + 1, faceNames[idx].replace(' ', '_'))
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WearFitFaces")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    true
} catch (e: Exception) { false }
