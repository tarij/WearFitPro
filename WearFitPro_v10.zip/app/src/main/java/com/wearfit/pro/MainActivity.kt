package com.wearfit.pro

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.hardware.*
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale

class MainActivity : ComponentActivity(), SensorEventListener {
    private val steps = mutableStateOf(0)
    private lateinit var hr: HeartRateClient

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        hr = HeartRateClient(this)
        val perms = mutableListOf(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 31) perms += listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else perms += Manifest.permission.ACCESS_FINE_LOCATION
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startSteps() }
            .launch(perms.toTypedArray())
        setContent { WearTheme { App(steps, hr) } }
    }

    private fun startSteps() {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val total = e.values[0].toInt()
        val p = getSharedPreferences("fit", MODE_PRIVATE)
        val today = LocalDate.now().toString()
        if (p.getString("day", "") != today) p.edit().putString("day", today).putInt("base", total).apply()
        steps.value = total - p.getInt("base", total)
        p.edit().putInt("steps_$today", steps.value).apply()
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

/* ------------------------------------------------------------------ */
/*  Root + floating navigation                                         */
/* ------------------------------------------------------------------ */

@SuppressLint("MissingPermission")
@Composable
fun App(steps: State<Int>, hr: HeartRateClient) {
    var tab by remember { mutableIntStateOf(0) }
    AppBackground {
        Box(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> Home(steps.value, hr.bpm.value)
                    1 -> Heart(hr)
                    2 -> Sleep()
                    3 -> Faces(steps.value, hr.bpm.value)
                    4 -> ActivityScreen()
                    else -> SettingsScreen()
                }
            }
        }
        NavBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
fun NavBar(tab: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf(
        "Home" to Icons.Default.Home,
        "Heart" to Icons.Default.Favorite,
        "Sleep" to Icons.Default.Bedtime,
        "Faces" to Icons.Default.Watch,
        "Activity" to Icons.Default.FitnessCenter,
        "Settings" to Icons.Default.Settings
    )
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0xF2101828))
            .border(1.dp, Ui.Line, RoundedCornerShape(30.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { i, item ->
            val label = item.first
            val sel = tab == i
            val bg by animateColorAsState(if (sel) Ui.Green else Color.Transparent, label = "navBg")
            val fg by animateColorAsState(if (sel) Color.Black else Ui.Muted, label = "navFg")
            Row(
                Modifier.clip(CircleShape).background(bg).clickable { onSelect(i) }
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.second, label, tint = fg, modifier = Modifier.size(22.dp))
                AnimatedVisibility(visible = sel) {
                    Text(
                        label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Home                                                               */
/* ------------------------------------------------------------------ */

@Composable
fun Home(steps: Int, bpm: Int) {
    val hp = Store.prefs(LocalContext.current)
    val goal = Store.stepGoal(hp)
    val uname = hp.getString("name", "") ?: ""
    val hour = LocalTime.now().hour
    val greet = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }
    val frac = (steps / goal.toFloat()).coerceIn(0f, 1f)
    val prog by animateFloatAsState(frac, tween(1000), label = "ring")
    val shown by animateIntAsState(steps, tween(800), label = "stepsNum")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Today", if (uname.isNotBlank()) "$greet, $uname" else greet)

        GlassCard(Modifier.fillMaxWidth(), Alignment.CenterHorizontally) {
            Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 26.dp.toPx()
                    val tl = Offset(stroke / 2, stroke / 2)
                    val arc = Size(size.width - stroke, size.height - stroke)
                    drawArc(Color(0x14FFFFFF), 0f, 360f, false, tl, arc, style = Stroke(stroke))
                    val sweep = Brush.sweepGradient(listOf(Ui.Cyan, Ui.Green), center)
                    rotate(-90f) {
                        drawArc(
                            brush = sweep, startAngle = 0f, sweepAngle = 360f * prog, useCenter = false,
                            topLeft = tl, size = arc, alpha = 0.28f,
                            style = Stroke(stroke * 1.5f, cap = StrokeCap.Round)
                        )
                        drawArc(
                            brush = sweep, startAngle = 0f, sweepAngle = 360f * prog, useCenter = false,
                            topLeft = tl, size = arc,
                            style = Stroke(stroke, cap = StrokeCap.Round)
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STEPS", color = Ui.Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                    Text("%,d".format(shown), color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Bold)
                    Text("of %,d".format(goal), color = Ui.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Pill("${(frac * 100).toInt()}%", Ui.Green)
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(Icons.Default.LocalFireDepartment, Ui.Orange, "Calories", "${(steps * Store.kcalPerStep(hp)).toInt()}", "kcal", Modifier.weight(1f))
            StatCard(Icons.Default.Place, Ui.Cyan, "Distance", "%.2f".format(Store.km(hp, steps)), "km", Modifier.weight(1f))
            StatCard(Icons.Default.Favorite, Ui.Pink, "Heart", if (bpm > 0) "$bpm" else "--", "bpm", Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Daily goal", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (steps >= goal) "Goal reached - great job!" else "%,d steps to go".format(goal - steps),
                        color = Ui.Muted, fontSize = 13.sp
                    )
                }
                Pill(if (steps >= goal) "Done" else "Active", if (steps >= goal) Ui.Green else Ui.Cyan)
            }
            Spacer(Modifier.height(12.dp))
            ProgressBar(prog, Brush.horizontalGradient(listOf(Ui.Cyan, Ui.Green)))
        }
        Spacer(Modifier.height(120.dp))
    }
}

@Composable
fun ProgressBar(fraction: Float, brush: Brush) {
    Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0.02f, 1f)).fillMaxHeight().clip(CircleShape).background(brush))
    }
}

@Composable
fun StatCard(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    GlassCard(modifier) {
        IconBadge(icon, tint)
        Spacer(Modifier.height(12.dp))
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("$label · $unit", color = Ui.Muted, fontSize = 11.sp, maxLines = 1)
    }
}

/* ------------------------------------------------------------------ */
/*  Heart                                                              */
/* ------------------------------------------------------------------ */

@SuppressLint("MissingPermission")
@Composable
fun Heart(hr: HeartRateClient) {
    val bpm = hr.bpm.value
    val period = if (bpm > 0) (60000 / bpm).coerceIn(300, 1200) else 900
    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 1f, targetValue = 1.14f,
        animationSpec = infiniteRepeatable(tween(period / 2, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "beat"
    )
    val zone = when {
        bpm <= 0 -> "No signal"
        bpm < 60 -> "Low"
        bpm < 100 -> "Resting"
        bpm < 140 -> "Active"
        else -> "Peak"
    }
    val connected = hr.status.value == "Connected"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Heart Rate", "Live from your watch")

        GlassCard(Modifier.fillMaxWidth(), Alignment.CenterHorizontally) {
            Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2
                    drawCircle(Ui.Pink.copy(alpha = 0.08f), r * 0.88f * pulse)
                    drawCircle(Ui.Pink.copy(alpha = 0.12f), r * 0.68f * pulse)
                    drawCircle(Ui.Pink.copy(alpha = 0.20f), r * 0.48f)
                }
                Icon(Icons.Default.Favorite, null, tint = Ui.Pink, modifier = Modifier.size(64.dp).scale(pulse))
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(if (bpm > 0) "$bpm" else "--", color = Color.White, fontSize = 60.sp, fontWeight = FontWeight.Bold)
                Text(" BPM", color = Ui.Muted, fontSize = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(zone, Ui.Pink)
                Pill(hr.status.value, if (connected) Ui.Green else Ui.Muted)
            }
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Live rhythm", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Canvas(Modifier.fillMaxWidth().height(90.dp)) {
                val h = hr.history.toList()
                if (h.size >= 2) {
                    val mn = (h.min() - 5).toFloat()
                    val mx = (h.max() + 5).toFloat()
                    val path = Path()
                    h.forEachIndexed { i, v ->
                        val x = size.width * i / (h.size - 1)
                        val y = size.height * (1f - (v - mn) / (mx - mn))
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, Ui.Pink, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                } else {
                    drawLine(Color(0x22FFFFFF), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 3f, StrokeCap.Round)
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { hr.scan() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Ui.Green, contentColor = Color.Black)
        ) {
            Icon(Icons.Default.Bluetooth, null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Scan for watch / band", fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(14.dp))
        if (hr.devices.isEmpty()) {
            Text(
                "No devices yet. Turn on heart-rate broadcast on your watch, then tap scan.",
                color = Ui.Muted, fontSize = 13.sp
            )
        }
        hr.devices.toList().forEach { d ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Default.Watch, Ui.Cyan, 40.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(d.name ?: "Unknown", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(d.address, color = Ui.Muted, fontSize = 12.sp)
                    }
                    FilledTonalButton(onClick = { hr.connect(d) }, shape = RoundedCornerShape(14.dp)) { Text("Connect") }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(120.dp))
    }
}

/* ------------------------------------------------------------------ */
/*  Sleep                                                              */
/* ------------------------------------------------------------------ */

@Composable
fun Sleep() {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("fit", Context.MODE_PRIVATE) }
    var hours by remember { mutableFloatStateOf(p.getFloat("sleep", 7f)) }
    val sleepGoal = Store.sleepGoal(p)
    val today = LocalDate.now()
    val week = (6 downTo 0).map { today.minusDays(it.toLong()) }

    val label: String
    val col: Color
    when {
        hours >= 9f -> { label = "Plenty of rest"; col = Ui.Cyan }
        hours >= sleepGoal -> { label = "Goal reached"; col = Ui.Green }
        hours >= 5f -> { label = "Almost there"; col = Ui.Orange }
        else -> { label = "Too short"; col = Ui.Pink }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Sleep", "Last night")

        GlassCard(Modifier.fillMaxWidth(), Alignment.CenterHorizontally) {
            IconBadge(Icons.Default.Bedtime, Ui.Purple, 56.dp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("%.1f".format(hours), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                Text(" hours", color = Ui.Muted, fontSize = 16.sp, modifier = Modifier.padding(bottom = 14.dp))
            }
            Pill(label, col)
            Spacer(Modifier.height(14.dp))
            Slider(
                value = hours,
                onValueChange = {
                    hours = it
                    p.edit().putFloat("sleep", it).putFloat("sleep_$today", it).apply()
                },
                valueRange = 0f..12f,
                colors = SliderDefaults.colors(
                    thumbColor = Ui.Purple,
                    activeTrackColor = Ui.Purple,
                    inactiveTrackColor = Color(0x22FFFFFF)
                )
            )
            Text("Drag to set your sleep - goal is %.1fh".format(sleepGoal), color = Ui.Muted, fontSize = 12.sp)
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("This week", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().height(130.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                week.forEach { d ->
                    val v = if (d == today) hours else p.getFloat("sleep_$d", 0f)
                    val isToday = d == today
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Box(
                            Modifier.width(20.dp).height(maxOf(4f, 96f * (v / 12f)).dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isToday) Brush.verticalGradient(listOf(Ui.Purple, Ui.Cyan))
                                    else Brush.verticalGradient(listOf(Color(0x558B7BFF), Color(0x228B7BFF)))
                                )
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            d.dayOfWeek.getDisplayName(java.time.format.TextStyle.NARROW, Locale.getDefault()),
                            color = if (isToday) Color.White else Ui.Muted, fontSize = 12.sp
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(120.dp))
    }
}
