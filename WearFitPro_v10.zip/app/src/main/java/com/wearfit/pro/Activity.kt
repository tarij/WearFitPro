package com.wearfit.pro

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun ReportRow(label: String, value: String, tint: Color = Color.White) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Ui.Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = tint, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ActivityScreen() {
    val ctx = LocalContext.current
    val p = remember { Store.prefs(ctx) }
    val workouts = remember { mutableStateListOf<Workout>().apply { addAll(Store.loadWorkouts(p)) } }
    var type by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableFloatStateOf(30f) }
    val weight = Store.weight(p)
    val goal = Store.stepGoal(p)
    val today = LocalDate.now()
    val week = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val stepsPerDay = week.map { p.getInt("steps_$it", 0) }
    val sleepDays = week.map { p.getFloat("sleep_$it", 0f) }.filter { it > 0f }
    val wk = workouts.filter { !it.day.isBefore(week.first()) }
    val totalSteps = stepsPerDay.sum()
    val maxS = maxOf(goal, stepsPerDay.maxOrNull() ?: 0).toFloat()
    val estKcal = (workoutTypes[type].second * weight * minutes / 60f).toInt()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Activity", "Workouts & weekly report")

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Weekly report", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().height(120.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                week.forEachIndexed { i, d ->
                    val v = stepsPerDay[i]
                    val hit = v >= goal
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Box(
                            Modifier.width(20.dp).height(maxOf(4f, 90f * v / maxS).dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (hit) Ui.Green else Ui.Cyan.copy(alpha = 0.45f))
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            d.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault()),
                            color = if (d == today) Color.White else Ui.Muted, fontSize = 12.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            ReportRow("Total steps", "%,d".format(totalSteps), Ui.Cyan)
            ReportRow("Daily average", "%,d".format(totalSteps / 7))
            ReportRow("Best day", "%,d".format(stepsPerDay.maxOrNull() ?: 0))
            ReportRow("Step goal met", "${stepsPerDay.count { it >= goal }} / 7 days", Ui.Green)
            ReportRow("Calories from steps", "${(totalSteps * Store.kcalPerStep(p)).toInt()} kcal", Ui.Orange)
            ReportRow("Workouts", "${wk.size}  •  ${wk.sumOf { it.minutes }} min  •  ${wk.sumOf { it.kcal }} kcal", Ui.Pink)
            ReportRow(
                "Average sleep",
                if (sleepDays.isEmpty()) "--" else "%.1f h".format(sleepDays.average()), Ui.Purple
            )
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Log a workout", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                workoutTypes.forEachIndexed { i, t ->
                    val on = i == type
                    Text(
                        t.first, color = if (on) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(CircleShape)
                            .background(if (on) Ui.Green else Color(0x14FFFFFF))
                            .clickable { type = i }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("${minutes.toInt()} min  •  about $estKcal kcal", color = Ui.Cyan, fontSize = 14.sp)
            Slider(
                value = minutes, onValueChange = { minutes = it }, valueRange = 5f..180f, steps = 34,
                colors = SliderDefaults.colors(
                    thumbColor = Ui.Green, activeTrackColor = Ui.Green, inactiveTrackColor = Color(0x22FFFFFF)
                )
            )
            Button(
                onClick = {
                    workouts.add(0, Workout(LocalDate.now(), workoutTypes[type].first, minutes.toInt(), estKcal))
                    Store.saveWorkouts(p, workouts)
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ui.Green, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Add workout", fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("History", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (workouts.isEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("No workouts yet", color = Ui.Muted, fontSize = 13.sp)
            }
            workouts.take(10).forEach { w ->
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(w.type, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${w.day.format(DateTimeFormatter.ofPattern("d MMM"))}  •  ${w.minutes} min  •  ${w.kcal} kcal",
                            color = Ui.Muted, fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { workouts.remove(w); Store.saveWorkouts(p, workouts) }) {
                        Icon(Icons.Default.Delete, "Delete", tint = Ui.Muted)
                    }
                }
            }
        }
        Spacer(Modifier.height(120.dp))
    }
}
