package com.wearfit.pro

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalTime

private val FIXED = LocalTime.of(10, 10, 30)

@Composable
fun rememberNow(): State<LocalTime> = produceState(LocalTime.now()) {
    while (true) { value = LocalTime.now(); delay(1000) }
}

@Composable
fun FacePreview(
    idx: Int, time: LocalTime, steps: Int, bpm: Int, corner: Dp,
    modifier: Modifier = Modifier, clock: Boolean = true
) {
    val shape = RoundedCornerShape(corner)
    Canvas(modifier.aspectRatio(FACE_W / FACE_H.toFloat()).clip(shape).border(1.dp, Color(0x33FFFFFF), shape)) {
        drawIntoCanvas { drawFace(it.nativeCanvas, size.width, size.height, idx, time, clock, steps, bpm) }
    }
}

@Composable
fun LivePreview(idx: Int, width: Dp, steps: Int, bpm: Int) {
    val t by rememberNow()
    FacePreview(idx, t, steps, bpm, 36.dp, Modifier.width(width))
}

@Composable
fun Faces(steps: Int, bpm: Int) {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("fit", Context.MODE_PRIVATE) }
    var sel by remember { mutableIntStateOf(p.getInt("face", 0).coerceIn(0, FACE_COUNT - 1)) }
    var withClock by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val btn = ButtonDefaults.buttonColors(containerColor = Ui.Green, contentColor = Color.Black)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Watch Faces", "$FACE_COUNT faces  •  ${FACE_W}×$FACE_H")
        GlassCard(Modifier.fillMaxWidth(), Alignment.CenterHorizontally) {
            LivePreview(sel, 220.dp, steps, bpm)
            Spacer(Modifier.height(12.dp))
            Text(faceNames[sel], color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Pill("Face ${sel + 1} / $FACE_COUNT", Ui.Green)
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Install on watch", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Save as ${FACE_W}×$FACE_H PNG, then in WearFit Pro set it as your custom watch face.",
                color = Ui.Muted, fontSize = 12.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = withClock, onCheckedChange = { withClock = it })
                Spacer(Modifier.width(8.dp))
                Text("Include clock in image", color = Color.White, fontSize = 13.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val i = sel; val c = withClock
                        Thread {
                            status = if (saveFace(ctx, i, c)) "Saved: ${faceNames[i]}" else "Save failed"
                        }.start()
                    },
                    shape = RoundedCornerShape(14.dp), colors = btn
                ) { Text("Save this", fontWeight = FontWeight.SemiBold) }
                OutlinedButton(
                    onClick = {
                        val c = withClock
                        Thread {
                            var ok = 0
                            for (i in 0 until FACE_COUNT) {
                                status = "Saving ${i + 1}/$FACE_COUNT..."
                                if (saveFace(ctx, i, c)) ok++
                            }
                            status = "Saved $ok/$FACE_COUNT to Pictures/WearFitFaces"
                        }.start()
                    },
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Save all $FACE_COUNT") }
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(status, color = Ui.Cyan, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Choose a face", color = Ui.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        (0 until FACE_COUNT).chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { i ->
                    val on = i == sel
                    Column(
                        Modifier.weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (on) Ui.Green.copy(alpha = 0.14f) else Color(0x0DFFFFFF))
                            .border(if (on) 1.5.dp else 1.dp, if (on) Ui.Green else Ui.Line, RoundedCornerShape(20.dp))
                            .clickable { sel = i; p.edit().putInt("face", i).apply() }
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FacePreview(i, FIXED, 0, 0, 14.dp, Modifier.fillMaxWidth())
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${i + 1}. ${faceNames[i]}", maxLines = 1,
                            color = if (on) Ui.Green else Color.White, fontSize = 11.sp
                        )
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(110.dp))
    }
}
