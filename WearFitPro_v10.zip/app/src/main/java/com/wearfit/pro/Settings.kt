package com.wearfit.pro

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingSlider(
    title: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>,
    stepsCount: Int, onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(title, color = Ui.Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range, steps = stepsCount,
            colors = SliderDefaults.colors(
                thumbColor = Ui.Green, activeTrackColor = Ui.Green, inactiveTrackColor = Color(0x22FFFFFF)
            )
        )
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val p = remember { Store.prefs(ctx) }
    var showDebug by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(p.getString("name", "") ?: "") }
    var stepGoal by remember { mutableFloatStateOf(Store.stepGoal(p).toFloat()) }
    var sleepGoal by remember { mutableFloatStateOf(Store.sleepGoal(p)) }
    var weight by remember { mutableFloatStateOf(Store.weight(p)) }
    var height by remember { mutableFloatStateOf(Store.height(p)) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Ui.Cyan, unfocusedBorderColor = Color(0x33FFFFFF),
        focusedLabelColor = Ui.Cyan, unfocusedLabelColor = Ui.Muted, cursorColor = Ui.Cyan
    )

    if (showDebug) {
        Column(Modifier.fillMaxSize()) {
            TextButton(onClick = { showDebug = false }) { Text("Back to settings", color = Ui.Cyan) }
            Box(Modifier.weight(1f)) { Debug() }
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            ScreenTitle("Settings", "Profile & goals")
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Profile", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it; p.edit().putString("name", it).apply() },
                    label = { Text("Your name") }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), colors = fieldColors, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                SettingSlider("Weight", "${weight.toInt()} kg", weight, 30f..150f, 0) {
                    weight = it; p.edit().putFloat("weight", it).apply()
                }
                SettingSlider("Height", "${height.toInt()} cm", height, 120f..210f, 0) {
                    height = it; p.edit().putFloat("height", it).apply()
                }
            }
            Spacer(Modifier.height(14.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Goals", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                SettingSlider("Daily steps", "%,d".format(stepGoal.toInt()), stepGoal, 2000f..20000f, 35) {
                    stepGoal = it; p.edit().putInt("goal_steps", it.toInt()).apply()
                }
                SettingSlider("Sleep", "%.1f h".format(sleepGoal), sleepGoal, 5f..10f, 9) {
                    sleepGoal = it; p.edit().putFloat("goal_sleep", it).apply()
                }
                Text("Weight and height are used for calories and distance.", color = Ui.Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Developer", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Scan the watch and view its raw Bluetooth data.", color = Ui.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { showDebug = true }, shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.BugReport, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Open Watch Debug")
                }
            }
            Spacer(Modifier.height(120.dp))
        }
    }
}
