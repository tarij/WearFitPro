package com.wearfit.pro

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.util.UUID

/** Connects to any watch/band exposing the standard BLE Heart Rate Service (0x180D). */
@SuppressLint("MissingPermission")
class HeartRateClient(private val ctx: Context) {
    val bpm = mutableStateOf(0)
    val status = mutableStateOf("Not connected")
    val history = mutableStateListOf<Int>()
    val devices = mutableStateListOf<BluetoothDevice>()
    private val svc = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
    private val chr = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val scanner get() =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.bluetoothLeScanner

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            if (devices.none { it.address == r.device.address }) devices.add(r.device)
        }
    }

    fun scan() {
        devices.clear(); status.value = "Scanning..."
        scanner?.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(svc)).build()),
            ScanSettings.Builder().build(), scanCb
        ) ?: run { status.value = "Bluetooth off" }
    }

    fun connect(d: BluetoothDevice) {
        scanner?.stopScan(scanCb); status.value = "Connecting..."
        d.connectGatt(ctx, false, gattCb)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, s: Int, n: Int) {
            if (n == BluetoothProfile.STATE_CONNECTED) { status.value = "Connected"; g.discoverServices() }
            else { status.value = "Disconnected"; bpm.value = 0 }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, s: Int) {
            val c = g.getService(svc)?.getCharacteristic(chr) ?: return
            g.setCharacteristicNotification(c, true)
            val d = c.getDescriptor(cccd)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }
        @Deprecated("API<33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            if (v.size < 2) return
            val x = if (v[0].toInt() and 1 == 0) v[1].toInt() and 0xFF
            else if (v.size >= 3) ((v[2].toInt() and 0xFF) shl 8) or (v[1].toInt() and 0xFF) else return
            bpm.value = x
            if (x in 30..230) {
                history.add(x)
                if (history.size > 40) history.removeAt(0)
            }
        }
    }
}
